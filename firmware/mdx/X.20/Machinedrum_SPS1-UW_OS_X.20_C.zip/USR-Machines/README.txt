USR MACHINES

SYN/  Synthesizer voices and filters inspired by late-70s and early-80s instruments

| Slot | File       | Machine          | Version | Description                                            |
| ---- | ---------- | ---------------- | ------- | ------------------------------------------------------ |
| U01  | SYN-O1.syx | SX-1 VCO         | 0.3     | Monosynth oscillator                                   |
| U02  | SYN-F1.syx | SX-1 VCF         | 0.2     | filter, envelope and VCA for SYN-O1 (track after it)   |
| U03  | SYN-O3.syx | TX-3 VCO         | 0.2     | Bass synth oscillator                                  |
| U04  | SYN-F3.syx | TX-3 VCF         | 0.2     | resonant filter and accent for SYN-O3 (track after it) |
| U05  | SYN-O8.syx | CS-8 VCO         | 0.2     | Polyphonic oscillator                                  |
| U06  | SYN-F8.syx | CS-8 VCF         | 0.2     | high- and low-pass filters for SYN-O8 (track after it) |
| U07  | SYN-OJ.syx | SY-OJ VCO 1+2    | 0.4     | Two polysynth oscillators                              |
| U08  | SYN-FJ.syx | SY-FJ VCF        | 0.2     | high- and low-pass filters for SYN-OJ (track after it) |
| U09  | SYN-VP.syx | SY-VP STRING VOX | 0.3     | Strings and voices                                     |

NFX/  Effects

| Slot | File       | Machine        | Version | Description                                       |
| ---- | ---------- | -------------- | ------- | ------------------------------------------------- |
| U01  | NFX-CH.syx | BBD CHORUS     | 0.2     | the chorus of an early-80s polysynth              |
| U02  | NFX-EN.syx | SY-VP ENSEMBLE | 0.3     | ensemble chorus of a late-70s string keyboard     |
| U04  | NFX-BC.syx | BUS COMP       | 0.2     | the bus compressor of an early-80s mixing console |
| U05  | NFX-FC.syx | FET COMP       | 0.3     | a late-60s FET limiting amplifier                 |
| U06  | NFX-D1.syx | DISTORTION     | 0.3     | a classic distortion pedal                        |
| U08  | NFX-D2.syx | OVERDRIVE      | 0.3     | a classic overdrive pedal                         |
| U09  | NFX-D3.syx | FUZZ           | 0.2     | a classic fuzz pedal                              |
| U10  | NFX-D4.syx | FILTER DISTORT | 0.2     | a classic distortion pedal with a sweeping filter |
| U07  | NFX-MX.syx | 4-TRACK MIXER  | 0.2     | a submix of the four tracks before it             |

TX8/  Drums of the classic early-80s analog drum machine

| Slot | File       | Machine         | Version | Description          |
| ---- | ---------- | --------------- | ------- | -------------------- |
| U01  | TX8-BD.syx | TX-8 BASS DRUM  | 0.2     | Bass drum            |
| U02  | TX8-SD.syx | TX-8 SNARE DRUM | 0.4     | Snare drum           |
| U03  | TX8-XT.syx | TX-8 TOM CONGA  | 0.3     | Tom conga            |
| U05  | TX8-RS.syx | TX-8 RIM SHOT   | 0.3     | Rim shot             |
| U10  | TX8-CL.syx | TX-8 CLAVES     | 0.2     | Claves               |
| U04  | TX8-CP.syx | TX-8 HAND CLAP  | 0.4     | Hand clap            |
| U11  | TX8-MA.syx | TX-8 MARACAS    | 0.3     | Maracas              |
| U09  | TX8-CB.syx | TX-8 COWBELL    | 0.2     | Cowbell              |
| U08  | TX8-CY.syx | TX-8 CYMBAL     | 0.2     | Cymbal               |
| U06  | TX8-HH.syx | TX-8 HIHAT      | 0.4     | Closed and open hats |

TX9/  Analog drums of a mid-80s drum machine

| Slot | File       | Machine         | Version | Description |
| ---- | ---------- | --------------- | ------- | ----------- |
| U01  | TX9-BD.syx | TX-9 BASS DRUM  | 0.3     | Bass drum   |
| U02  | TX9-SD.syx | TX-9 SNARE DRUM | 0.3     | Snare drum  |
| U03  | TX9-XT.syx | TX-9 TOM        | 0.3     | Tom         |
| U05  | TX9-RS.syx | TX-9 RIM SHOT   | 0.3     | Rim shot    |
| U04  | TX9-CP.syx | TX-9 HAND CLAP  | 0.3     | Hand clap   |

TX6/  Drums of a small early-80s analog drum machine

| Slot | File       | Machine         | Version | Description |
| ---- | ---------- | --------------- | ------- | ----------- |
| U01  | TX6-BD.syx | TX-6 BASS DRUM  | 0.2     | Bass drum   |
| U02  | TX6-SD.syx | TX-6 SNARE DRUM | 0.2     | Snare drum  |
| U03  | TX6-XT.syx | TX-6 TOM        | 0.3     | Tom         |
| U04  | TX6-CH.syx | TX-6 CLOSED HAT | 0.2     | Closed hat  |
| U05  | TX6-OH.syx | TX-6 OPEN HAT   | 0.2     | Open hat    |
| U06  | TX6-CY.syx | TX-6 CYMBAL     | 0.2     | Cymbal      |

TXZ/  Patches of a mid-80s four-operator FM rack synth

| Slot | File       | Machine          | Version | Description          |
| ---- | ---------- | ---------------- | ------- | -------------------- |
| U01  | TXZ-EP.syx | TXZ ELECTRIC PNO | 0.7     | Electric piano patch |
| U02  | TXZ-LB.syx | TXZ LATE BASS    | 0.7     | Bass patch           |
| U03  | TXZ-LD.syx | TXZ HEAVY LEAD   | 0.7     | Lead patch           |
| U04  | TXZ-PD.syx | TXZ HARMO PAD    | 0.7     | Pad patch            |
| U05  | TXZ-ST.syx | TXZ SYN STRING   | 0.7     | String patch         |
| U10  | TXZ-SC.syx | TXZ SOFT CLOUD   | 0.1     | Pad patch            |
| U07  | TXZ-CE.syx | TXZ CELESTE      | 0.1     | Percussive patch     |
| U11  | TXZ-SS.syx | TXZ SOFT STRING  | 0.1     | String patch         |
| U06  | TXZ-BB.syx | TXZ BREATH BRASS | 0.1     | Brass patch          |
| U08  | TXZ-EO.syx | TXZ E.ORGAN      | 0.1     | Organ patch          |
| U09  | TXZ-FL.syx | TXZ FLUTE        | 0.1     | Flute patch          |

P-I/  Plucked, struck and bowed instruments

| Slot | File       | Machine      | Version | Description                                |
| ---- | ---------- | ------------ | ------- | ------------------------------------------ |
| U01  | P-I-PN.syx | PIANO        | 0.5     | an acoustic piano with interacting strings |
| U02  | P-I-EP.syx | E PIANO      | 0.4     | an electric piano with struck tines        |
| U03  | P-I-HP.syx | HANDPAN      | 0.6     | the tuned steel notes of a handpan         |
| U04  | P-I-ST.syx | STRING       | 0.4     | plucked and struck strings                 |
| U05  | P-I-BW.syx | BOWED STRING | 0.6     | a bowed string                             |
